import 'package:flutter/material.dart';
import 'dart:async';
import 'package:blue_thermal_printer/blue_thermal_printer.dart';
import 'package:flutter/services.dart';

class BluePrint extends StatefulWidget {
  static const routeName = 'BluePrint';

  @override
  _BluePrintState createState() => _BluePrintState();
}

class _BluePrintState extends State<BluePrint> {
  BlueThermalPrinter bluetooth = BlueThermalPrinter.instance;

  List<BluetoothDevice> _devices = [];
  BluetoothDevice _device;
  bool _connected = false;
  bool _pressed = false;
  String pathImage;

  @override
  void initState() {
    super.initState();
    initPlatformState();
    // initSavetoPath();
  }

  // initSavetoPath() async {
  //   //read and write
  //   //image max 300px X 300px
  //   final filename = 'yourlogo.png';
  //   // var bytes = await rootBundle.load("assets/images/yourlogo.png");
  //   String dir = (await getApplicationDocumentsDirectory()).path;
  //   writeToFile(context.read<AppProvider>().imgBytes, '$dir/$filename');
  //   setState(() {
  //     pathImage = '$dir/$filename';
  //   });
  // }

  Future<void> initPlatformState() async {
    List<BluetoothDevice> devices = [];

    try {
      devices = await bluetooth.getBondedDevices();
    } on PlatformException {
      // TODO - Error
    }

    if (!mounted) return;
    setState(() {
      _devices = devices;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Blue Thermal Printer'),
        ),
        body: Container(
          child: ListView(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 0.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Text(
                      'Device:',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    DropdownButton(
                      items: _getDeviceItems(),
                      onChanged: (value) => setState(() => _device = value),
                      value: _device,
                    ),
                    RaisedButton(
                      onPressed: _pressed
                          ? null
                          : _connected
                              ? _disconnect
                              : _connect,
                      child: Text(_connected ? 'Disconnect' : 'Connect'),
                    ),
                  ],
                ),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(left: 10.0, right: 10.0, top: 50),
                child: RaisedButton(
                  onPressed: _connected ? _tesPrint : null,
                  child: Text('TesPrint'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  List<DropdownMenuItem<BluetoothDevice>> _getDeviceItems() {
    List<DropdownMenuItem<BluetoothDevice>> items = [];
    if (_devices.isEmpty) {
      items.add(DropdownMenuItem(
        child: Text('NONE'),
      ));
    } else {
      _devices.forEach((device) {
        items.add(DropdownMenuItem(
          child: Text(device.name),
          value: device,
        ));
      });
    }
    return items;
  }

  void _connect() {
    if (_device == null) {
      show('No device selected.');
    } else {
      bluetooth.isConnected.then((isConnected) {
        if (!isConnected) {
          bluetooth.connect(_device).catchError((error) {
            setState(() => _pressed = false);
          });
          //show message
          //storage
          setState(() => _pressed = true);
        }
      });
    }
  }

  void _disconnect() {
    bluetooth.disconnect();
    setState(() => _pressed = true);
  }

//write to app path
  // Future<void> writeToFile(ByteData data, String path) {
  //   final buffer = data.buffer;
  //   return new File(path).writeAsBytes(
  //       buffer.asUint8List(data.offsetInBytes, data.lengthInBytes));
  // }

  void _tesPrint() async {
    List data = [{"value":"SP_Bakery Cream Roll 3 pack 3 pa"},{"value":"ck    Price"}];
    //SIZE
    // 0- normal size text
    // 1- only bold text
    // 2- bold with medium text
    // 3- bold with large text
    //ALIGN
    // 0- ESC_ALIGN_LEFT
    // 1- ESC_ALIGN_CENTER
    // 2- ESC_ALIGN_RIGHT
    //CHARACTAR
    // 64 charactar
    
    //SKU-35
    //SPACE-1
    //PRICE-6
    //SPACE-1
    //Dis-6
    //SPACE-1
    //QTY-4
    //SPACE-1
    //Amount-9
    bluetooth.isConnected.then((isConnected) {
      if (isConnected) {
        
        bluetooth.printCustom("SKU                                 Price  Dis(%)  Qty    Amount", 0, 0);
        for(var i = 0; i < data.length;i++){
          bluetooth.printCustom(data[i].value, 0, 0);
        }
        bluetooth.printCustom("SP_Bakery Cream Roll 3 pack         789.21   99.89 1234 789012.34", 0, 0);
        bluetooth.printCustom("-----------------------------------------------------------------", 0, 0);
        // bluetooth.printCustom("Store : $storename", 0, 0);
        bluetooth.printCustom("Sub Total                                              1000000.00", 0, 0);
        bluetooth.printNewLine();
        // bluetooth.printCustom("အစမ်းထုတ်", 2, 1);
        // bluetooth.printCustom(
        //   context.read<AppProvider>().input,
        //   400,
        //   1,
        // );

        // bluetooth.printImage(pathImage);
        // bluetooth.printNewLine();

        // bluetooth.printLeftRight("LEFT", "RIGHT", 1);
        // bluetooth.printNewLine();
        // bluetooth.printLeftRight("LEFT", "RIGHT", 2);
        // bluetooth.printCustom("Body left", 1, 0);
        // bluetooth.printCustom("Body right", 0, 2);
        // bluetooth.printNewLine();
        // bluetooth.printCustom("Terimakasih", 2, 1);
        bluetooth.printNewLine();
        // bluetooth.printQRcode("Insert Your Own Text to Generate");
        bluetooth.printNewLine();
        bluetooth.printNewLine();
        bluetooth.paperCut();
      }
    });
  }

  Future show(
    String message, {
    Duration duration: const Duration(seconds: 3),
  }) async {
    await new Future.delayed(new Duration(milliseconds: 100));
    Scaffold.of(context).showSnackBar(
      new SnackBar(
        content: new Text(
          message,
          style: new TextStyle(
            color: Colors.white,
          ),
        ),
        duration: duration,
      ),
    );
  }
}
